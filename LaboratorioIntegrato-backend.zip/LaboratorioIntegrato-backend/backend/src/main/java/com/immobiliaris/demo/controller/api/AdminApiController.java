package com.immobiliaris.demo.controller.api;

import com.immobiliaris.demo.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminApiController {
    private static final Logger logger = LoggerFactory.getLogger(AdminApiController.class);

    @Autowired
    private StatisticsService statisticsService;

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard(Authentication authentication) {
        Map<String, Object> response = new LinkedHashMap<>();

        try {
            // Ottieni statistiche complete dal Service
            Map<String, Object> dashboardData = statisticsService.getAdminDashboardData();

            // Ordine della risposta JSON
            response.put("statistics", dashboardData.get("statistics"));
            response.put("top3Agenti", dashboardData.get("top3Agenti"));
            response.put("contrattiPerMese", dashboardData.get("contrattiPerMese"));
            response.put("agenti", dashboardData.get("agenti"));
            response.put("tempoAIaPresaInCarico", dashboardData.get("tempoAIaPresaInCarico"));
            response.put("tempoPresaInCaricoaContratto", dashboardData.get("tempoPresaInCaricoaContratto"));
            response.put("valutazionePerformancePresaInCarico", dashboardData.get("valutazionePerformancePresaInCarico"));
            response.put("valutazionePerformanceContratto", dashboardData.get("valutazionePerformanceContratto"));
            response.put("immobiliPerTipo", dashboardData.get("immobiliPerTipo"));

        } catch (Exception e) {
            // Se c'è errore, ritorna almeno le info base
            System.err.println("Errore caricamento dashboard: " + e.getMessage());
            logger.error("Errore caricamento dashboard: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
        }

        return ResponseEntity.ok(response);
    }

    /**
     * API per ottenere immobili con tutti i dettagli inclusi prezzoAI e prezzoUmano
     * GET /api/admin/immobili?offset=0&limit=12
     * @param offset Offset per la paginazione
     * @param limit Numero elementi da restituire (default 12)
     */
    @GetMapping("/immobili")
    public ResponseEntity<Map<String, Object>> getImmobiliCompleti(
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "12") int limit) {
        
        Map<String, Object> result = statisticsService.getTuttiImmobiliConDettagli(offset, limit);
        return ResponseEntity.ok(result);
    }

    /**
     * Endpoint per il pulsante "Carica altri" nel frontend.
     * Usa offset (numero di elementi già caricati) e limit (quantità da caricare)
     * Esempio: GET /api/admin/immobili/load?offset=0&limit=10
     */
    

    /**
     * Restituisce contratti chiusi con i dettagli degli immobili associati
     * Usa offset/limit per load-more progressivo (come dashboard)
     * Esempio: GET /api/admin/contratti/chiusi?offset=0&limit=10
     */
    @GetMapping("/contratti/chiusi")
    public ResponseEntity<Object> getContrattiChiusi(
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {
        try {
            return ResponseEntity.ok(statisticsService.getContrattiChiusiLoadMore(offset, limit));
        } catch (Exception e) {
            logger.error("Errore recupero contratti: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body("Errore recupero contratti");
        }
    }

    /**
     * Restituisce valutazioni generate solo da AI con i dettagli degli immobili
     * Usa offset/limit per load-more progressivo
     * Esempio: GET /api/admin/valutazioni/solo-ai?offset=0&limit=10
     */
    @GetMapping("/valutazioni/solo-ai")
    public ResponseEntity<Object> getValutazioniSoloAI(
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {
        try {
            return ResponseEntity.ok(statisticsService.getValutazioniSoloAILoadMore(offset, limit));
        } catch (Exception e) {
            logger.error("Errore recupero valutazioni: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body("Errore recupero valutazioni");
        }
    }

    /**
     * Restituisce valutazioni in verifica con TUTTI i campi della tabella valutazione
     * Usa offset/limit per load-more progressivo
     * Esempio: GET /api/admin/valutazioni/in-verifica?offset=0&limit=10
     */
    @GetMapping("/valutazioni/in-verifica")
    public ResponseEntity<Object> getValutazioniInVerifica(
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit) {
        try {
            return ResponseEntity.ok(statisticsService.getValutazioniInVerficaLoadMore(offset, limit));
        } catch (Exception e) {
            logger.error("Errore recupero valutazioni in verifica: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body("Errore recupero valutazioni in verifica");
        }
    }

    /**
     * Elimina una valutazione AI per ID
     * Esempio: DELETE /api/admin/valutazioni/solo-ai/5
     */
    @DeleteMapping("/valutazioni/solo-ai/{id}")
    public ResponseEntity<Object> deleteValutazioneAI(@PathVariable Integer id) {
        try {
            statisticsService.deleteValutazione(id);
            return ResponseEntity.ok(Map.of("success", true, "message", "Valutazione AI eliminata con successo"));
        } catch (Exception e) {
            logger.error("Errore eliminazione valutazione: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "Errore eliminazione valutazione: " + e.getMessage()));
        }
    }

    /**
     * Elimina una valutazione in verifica per ID
     * Esempio: DELETE /api/admin/valutazioni/in-verifica/7
     */
    @DeleteMapping("/valutazioni/in-verifica/{id}")
    public ResponseEntity<Object> deleteValutazioneInVerifica(@PathVariable Integer id) {
        try {
            statisticsService.deleteValutazione(id);
            return ResponseEntity.ok(Map.of("success", true, "message", "Valutazione in verifica eliminata con successo"));
        } catch (Exception e) {
            logger.error("Errore eliminazione valutazione: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "Errore eliminazione valutazione: " + e.getMessage()));
        }
    }

    /**
     * Modifica una valutazione in verifica per ID
     * Esempio: PUT /api/admin/valutazioni/in-verifica/7
     */
    @PutMapping("/valutazioni/in-verifica/{id}")
    public ResponseEntity<Object> updateValutazioneInVerifica(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> updates) {
        try {
            statisticsService.updateValutazione(id, updates);
            return ResponseEntity.ok(Map.of("success", true, "message", "Valutazione aggiornata con successo"));
        } catch (Exception e) {
            logger.error("Errore aggiornamento valutazione: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "Errore aggiornamento valutazione: " + e.getMessage()));
        }
    }

    /**
     * Assegna un agente a una valutazione solo_AI
     * Esempio: PUT /api/admin/valutazioni/solo-ai/{id}/assegna-agente
     * Body: { "idAgente": 123 }
     */
    @PutMapping("/valutazioni/solo-ai/{id}/assegna-agente")
    public ResponseEntity<Object> assegnaAgenteValutazioneAI(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> body) {
        try {
            // Converti il valore JSON (che può essere Integer) in Long
            Long idAgente = ((Number) body.get("idAgente")).longValue();
            statisticsService.assegnaAgenteValutazioneAI(id, idAgente);
            return ResponseEntity.ok(Map.of("success", true, "message", "Agente assegnato con successo"));
        } catch (Exception e) {
            logger.error("Errore assegnazione agente: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "Errore assegnazione agente: " + e.getMessage()));
        }
    }
}
